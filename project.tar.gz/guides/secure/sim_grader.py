# from .autograder import Assessment
import autograder
from functools import partial
import re
import os 
import sys
from time import sleep
import subprocess

# function to normalize the whitespace/newlines of a string
def normalize(a : str):
  return re.sub("\n|\s", " ", a)

def test_valgrind(script_to_invoke, test_file_name, *obj_files):
  os.system(f"touch {output_path}/{test_file_name}.txt")

  # join the obj files and call the script
  objs = " ".join([soln_path + "/" + o for o in (f"{test_file_name}.obj",) + obj_files])
  try:
    p = subprocess.run(f"valgrind --leak-check=full ./{script_to_invoke} {output_path}/{test_file_name}.txt {objs}".split(" "), stdout=subprocess.PIPE, stderr = subprocess.PIPE, timeout=timeout)
  except subprocess.TimeoutExpired:
    return False, f"Test {test_file_name} timed out."
  except Exception as e:
    print(e)
    return False, f"Test {test_file_name} could not be invoked. Make sure that your Makefile is compiling trace correctly."
  
  if "All heap blocks were freed -- no leaks are possible" in str(p.stderr) and "ERROR SUMMARY: 0 errors from 0 contexts (suppressed: 0 from 0)" in str(p.stderr):
    return True, ""
  else:
    return False, f"Valgrind detected a memory leak or error in {test_file_name} with the following output: \n\n{str(p.stderr.decode())}"

def test_similarity_full(script_to_invoke, test_file_name, *obj_files) -> bool:
  # make the output file
  p = subprocess.Popen(f"rm {output_path}/{test_file_name}.txt".split(), stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
  # os.system(f"touch {output_path}/{test_file_name}.txt")

  # join the obj files and call the script
  objs = " ".join([soln_path + "/" + o for o in (f"{test_file_name}.obj",) + obj_files])
  try:
    p = subprocess.Popen(f"./{script_to_invoke} {output_path}/{test_file_name}.txt {objs}".split(" "), stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
  except:
    return False, f"Test {test_file_name} could not be invoked. Make sure that your Makefile is compiling trace correctly."
  try:
      p.wait(timeout)
  except subprocess.TimeoutExpired:
      p.kill()
      return False, f"Test {test_file_name} timed out."

  # get the expected and found output
  expected = ""
  with open(f"{soln_path}/{test_file_name}.txt", "r") as f:
    expected = f.read()

  actual = ""
  if not os.path.isfile(f"{output_path}/{test_file_name}.txt"):
    return False, f"Test {test_file_name} did not output a file."

  with open(f"{output_path}/{test_file_name}.txt", "r") as f:
    actual = f.read()


  expected = normalize(expected) 
  actual = normalize(actual)
  
  l = 0
  for bidx in range(len(expected)):
      if bidx >= len(actual) or actual[bidx] != expected[bidx]:
          return False, f"Test {test_file_name} failed: your output file differed from the reference at char {bidx} with the following values\nYour code:\n{actual[max(0, bidx - 8):min(bidx + 8, len(actual))]}\nExpected code:\n{expected[max(0, bidx - 8):min(bidx + 8, len(expected))]}\n"
      l = bidx
  
  if l + 1 != len(actual):
    # print("MAX:", max(0, l - 8))
    return False, f"Test {test_file_name} failed: your output file continued after the reference ended at char {l}.\nYour output:\n{actual[max(0, bidx - 8):min(bidx + 8, len(actual))]}\nExpected code:\n{expected[max(0, l - 8):]} EOF\n"

  return True, ""

ver = sys.argv[1]
timeout = 3
soln_path = ".guides/secure/p2_test_cases"
output_path = ".guides/secure/out"
subprocess.run("make clean".split(), stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
subprocess.run("make all".split(), stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
subprocess.run("mkdir .guides/secure/out".split(), stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
# os.system("make all")
# os.system("mkdir .guides/secure/out")
a = autograder.Assessment()

test_similarity = partial(test_similarity_full, "trace")


if ver == '"student-facing"':

  a.add_test(test_similarity, 1, "public-BR_arith")
  a.add_test(test_similarity, 1, "public-branch0")
  a.add_test(test_similarity, 1, "public-test_basic")
  a.add_test(test_similarity, 1, "public-test_checkers_img")
  a.add_test(test_similarity, 1, "public-test_trap_rti_ldr_str")
  a.add_test(test_similarity, 1, "wireframe", "os.obj")
  a.add_test(test_similarity, 1, "triangle", "os.obj")
  pts, msgs_out, penalty = a.run_tests()
  print(f"Total score: {round(100 * pts/a.total_pts)}%")
  if pts == a.total_pts:
    print("It looks like all of the test cases passed. Congratulations!")
    sys.exit(0)
  else:
    print(msgs_out)
    sys.exit(1)
elif ver == '"student-valgrind"':
  a.add_test(test_valgrind, 1, "trace", "public-branch0")
  pts, msgs_out, penalty = a.run_tests()
  print(f"Total score: {round(100 * pts/a.total_pts)}%")
  if pts == a.total_pts:
    print("It looks like all of the test cases passed. Congratulations!")
    sys.exit(0)
  else:
    print(msgs_out)
    sys.exit(1)

else:

  a.add_test(test_similarity, 1, "public-BR_arith")
  a.add_test(test_similarity, 1, "public-branch0")
  a.add_test(test_similarity, 1, "public-test_basic")
  a.add_test(test_similarity, 1, "public-test_checkers_img")
  a.add_test(test_similarity, 1, "public-test_trap_rti_ldr_str")
  a.add_test(test_similarity, 1, "wireframe", "os.obj")
  a.add_test(test_similarity, 1, "triangle", "os.obj")
  a.add_test(test_valgrind, 1, "trace", "public-branch0")
  a.run_tests_and_send()