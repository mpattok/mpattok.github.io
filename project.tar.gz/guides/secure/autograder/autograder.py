import sys
from typing import List, Callable, Tuple, Optional
import os



class Assessment():

  def __init__(self):
    self.tests : List[Test] = []
    self.total_pts = 0

  def add_test(self, test : Callable[..., Tuple[bool, str, Optional[int]]], points : int, *args) -> None:
    """
    Defines a new test case for the assessment

    Parameters
    ----------
    test : Callable[..., Tuple[bool, str, Optional[int]]]
    The method that should be called in order to run the test. The function can take any number of args, though those args must be included in the call to add_test. The output of the callable must be either a 2-element or 3-element tuple which includes 1) a boolean denoting whether the test succeeded, 2) a string with feedback, and optionally 3) an int denoting the number of penalty points to be detracted.
    points : int
    The number of points that should be assigned if the test succeeds
    *args
    Any args that should be supplied to the test function at runtime
    """
    self.tests.append(Test(test, points, args))
    self.total_pts += points

  def run_tests(self):
    """Runs all tests cases and returns the output."""
    points_earned = 0
    msgs_out = ""
    penalty = 0
    for t in self.tests:

      succ = False
      msg = ""
      pen = 0
      out = t.run()

      if (len(out) == 3):
        succ, msg, pen = out
      elif (len(out) == 2):
        succ, msg = out
      else:
        raise TypeError("The test function should return either 2 or 3 values. See the documentation for add_test for more info.")

      if msg != "":
        msgs_out += msg
        msgs_out += '\n'

      if succ:
        points_earned += t.points
      penalty += pen

    return points_earned, msgs_out, penalty

  def run_tests_and_send(self) -> bool:
    """
    Runs all test cases and sends them to Codio

    Returns
    -------
    bool
    Denotes whether the data was successfully sent to Codio or not

    Raises
    ------
    TypeError
    If the test function returns something other than a 2 or 3 element tuple
    """

    # # import grade submit function
    sys.path.append('/usr/share/codio/assessments')
    from lib.grade import send_grade_v2, FORMAT_V2_MD, FORMAT_V2_HTML, FORMAT_V2_TXT
    try:
      CODIO_AUTOGRADE_URL = os.environ["CODIO_AUTOGRADE_URL"]
      CODIO_UNIT_DATA = os.environ["CODIO_AUTOGRADE_ENV"]
    except: 
      CODIO_AUTOGRADE_URL = ""
      CODIO_UNIT_DATA = ""
    points_earned, msgs_out, penalty = self.run_tests()
    return send_grade_v2(int(round((points_earned / self.total_pts) * 100)), msgs_out, penalty=penalty)

class Test():
  def __init__(self, assessment : Callable[..., Tuple[bool, str, Optional[int]]], points : int, args):
    self.assessment : Callable[..., Tuple[bool, str, Optional[int]]] = assessment
    self.points : int = points
    self.args = args

  def run(self) -> Tuple[bool, str, Optional[int]]:
    return self.assessment(*self.args)
