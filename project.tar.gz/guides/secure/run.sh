#!/bin/bash

cd .guides/secure
python3 sim_grader.py