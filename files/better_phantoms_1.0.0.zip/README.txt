Better Phantoms by DJPeters
Version: 1.0.0

Introduction:

This pack changes the spawning behaviour of Phantoms in your world. It can be configured in-game using the correct function command. There are now three possible methods for spawning Phantoms.

The default behavior of this pack disables Phantom spawning completely, meaning you won't need to worry about sleeping any longer! It also adds the Phantom Membrane as a drop from Endermites (Referred to as an "Ender Membrane") allowing you to still repair your Elytra and brew Slow Falling potions.

The second option is to turn the Phantom into a neutral mob, meaning it will only attack you if it is attacked first. Unfortunately, due to a bug in 1.13, this option doesn't function properly.

The final option is to enable normal spawning behavior. Phantoms will still attack and Endermites will not drop membranes.

The command for editing Phantom spawning behavior is /function better_phantoms:behavior